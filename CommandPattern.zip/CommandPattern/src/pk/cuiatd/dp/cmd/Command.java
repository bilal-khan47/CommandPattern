package pk.cuiatd.dp.cmd;

public interface Command {
	void execute();
	void undo();
}
